setwd("C:\\Users\\it24100340\\Desktop\\IT24100340")
n <- 50
p <- 0.85

prob_40 <- dbinom(40, size = n, prob = p)
print(paste("P(X=40) =", prob_40))

prob_leq_35 <- pbinom(35, size = n, prob = p)
print(paste("P(X <= 35) =", prob_leq_35))

prob_geq_38 <- 1 - pbinom(37, size = n, prob = p)
print(paste("P(X >= 38) =", prob_geq_38))

prob_40_to_42 <- pbinom(42, size = n, prob = p) - pbinom(39, size = n, prob = p)
print(paste("P(40 <= X <= 42) =", prob_40_to_42))

lambda <- 5

prob_6 <- dpois(6, lambda = lambda)
print(paste("P(X=6) =", prob_6))

prob_gt_6 <- 1 - ppois(6, lambda = lambda)
print(paste("P(X > 6) =", prob_gt_6))

n_students <- 50
p_pass <- 0.85

prob_at_least_47 <- 1 - pbinom(46, size = n_students, prob = p_pass)
print(paste("P(X >= 47) =", prob_at_least_47))

lambda_calls <- 12

prob_15_calls <- dpois(15, lambda = lambda_calls)
print(paste("P(X=15) =", prob_15_calls))